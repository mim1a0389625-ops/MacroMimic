MacroMimic - مقلّد الحركات (Android)
1) افتح المجلد بـ Android Studio (File > Open) وانتظر Sync.
2) شغّل على جوالك (USB debugging) أو Build > Build APK(s).
3) افتح التطبيق > فعّل خدمة الوصول > أظهر اللوحة.
