package com.example.macromimic

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var stepsInfo: TextView
    private lateinit var repeatEdit: EditText

    private val speeds = floatArrayOf(0.5f, 1f, 1.5f, 2f, 3f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(t: String, size: Float = 16f) = TextView(this).apply {
            this.text = t
            textSize = size
            setPadding(0, (8 * d).toInt(), 0, (8 * d).toInt())
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            this.text = t
            setOnClickListener { onClick() }
        }

        root.addView(label("مقلّد الحركات", 26f))
        status = label("")
        root.addView(status)

        root.addView(button("1) فعّل خدمة الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("2) أظهر اللوحة العائمة") {
            val s = MacroService.instance
            if (s == null) toast("فعّل الخدمة أول من الخطوة 1") else s.showPanel()
        })

        root.addView(label("عدد مرات التكرار (0 = بلا نهاية)"))
        repeatEdit = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Store.repeat(this@MainActivity).toString())
        }
        root.addView(repeatEdit)

        root.addView(label("سرعة التشغيل"))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("0.5x", "1x", "1.5x", "2x", "3x")
        )
        spinner.setSelection(speeds.indexOf(Store.speed(this)).coerceAtLeast(1))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Store.setSpeed(this@MainActivity, speeds[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spinner)

        stepsInfo = label("")
        root.addView(stepsInfo)
        root.addView(button("مسح الخطوات المحفوظة") {
            Store.save(this, emptyList())
            refresh()
        })

        root.addView(
            label(
                "طريقة الاستخدام:\n" +
                    "• افتح اللعبة وأظهر اللوحة.\n" +
                    "• ● يبدأ التسجيل، العب بشكل عادي، ■ يوقف.\n" +
                    "• ▶ يعيد نفس الخطوات. ■ يوقف التشغيل.\n" +
                    "• اسحب اللوحة من ☰ وحطها بزاوية ما بتحتاجها اللعبة.",
                14f
            )
        )

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        super.onPause()
        val r = repeatEdit.text.toString().toIntOrNull() ?: 1
        Store.setRepeat(this, r.coerceAtLeast(0))
    }

    private fun refresh() {
        status.text = if (MacroService.instance != null)
            "✅ الخدمة شغّالة" else "❌ الخدمة مطفية: فعّلها من إعدادات الوصول"
        stepsInfo.text = "الخطوات المحفوظة: ${Store.load(this).size}"
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
