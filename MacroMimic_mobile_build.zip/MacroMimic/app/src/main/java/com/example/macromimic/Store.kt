package com.example.macromimic

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** خطوة واحدة: لمسة أو سحبة. offset = وقت بدايتها بالنسبة لأول خطوة (ms). */
data class Step(
    val offset: Long,
    val duration: Long,
    val x1: Float,
    val y1: Float,
    val x2: Float,
    val y2: Float
)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("macro", Context.MODE_PRIVATE)

    fun save(c: Context, steps: List<Step>) {
        val arr = JSONArray()
        steps.forEach {
            arr.put(
                JSONObject()
                    .put("o", it.offset).put("d", it.duration)
                    .put("x1", it.x1.toDouble()).put("y1", it.y1.toDouble())
                    .put("x2", it.x2.toDouble()).put("y2", it.y2.toDouble())
            )
        }
        prefs(c).edit().putString("steps", arr.toString()).apply()
    }

    fun load(c: Context): List<Step> {
        val s = prefs(c).getString("steps", null) ?: return emptyList()
        val arr = JSONArray(s)
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Step(
                o.getLong("o"), o.getLong("d"),
                o.getDouble("x1").toFloat(), o.getDouble("y1").toFloat(),
                o.getDouble("x2").toFloat(), o.getDouble("y2").toFloat()
            )
        }
    }

    fun repeat(c: Context): Int = prefs(c).getInt("repeat", 1)
    fun setRepeat(c: Context, v: Int) = prefs(c).edit().putInt("repeat", v).apply()

    fun speed(c: Context): Float = prefs(c).getFloat("speed", 1f)
    fun setSpeed(c: Context, v: Float) = prefs(c).edit().putFloat("speed", v).apply()
}
