package com.example.macromimic

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

class MacroService : AccessibilityService() {

    companion object {
        var instance: MacroService? = null
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var statusView: TextView? = null

    private var recLayer: View? = null
    private var recLp: WindowManager.LayoutParams? = null

    private var recording = false
    private var playing = false
    private val recorded = mutableListOf<Step>()
    private var firstDown = -1L
    private var downX = 0f
    private var downY = 0f
    private var downT = 0L

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        hidePanel()
        instance = null
        return super.onUnbind(intent)
    }

    // ───────────── اللوحة العائمة ─────────────

    fun showPanel() {
        if (panel != null) return
        val d = resources.displayMetrics.density

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xE6222222.toInt())
        }

        fun item(label: String, color: Int, onClick: (() -> Unit)?): TextView =
            TextView(this).apply {
                text = label
                setTextColor(color)
                textSize = 20f
                setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
                if (onClick != null) setOnClickListener { onClick() }
                row.addView(this)
            }

        val handle = item("☰", Color.LTGRAY, null)
        item("●", Color.RED) { startRecording() }
        item("■", Color.WHITE) { stopAll() }
        item("▶", Color.GREEN) { startPlayback() }
        item("✕", Color.LTGRAY) { hidePanel() }
        statusView = item("جاهز", Color.LTGRAY, null).apply { textSize = 12f }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = (16 * d).toInt()
            y = (120 * d).toInt()
        }

        // سحب اللوحة من مقبض ☰
        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt()
                        lp.y = sy + (e.rawY - ty).toInt()
                        wm.updateViewLayout(row, lp)
                    }
                }
                return true
            }
        })

        wm.addView(row, lp)
        panel = row
        panelLp = lp
    }

    private fun hidePanel() {
        stopAll()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        panelLp = null
        statusView = null
    }

    private fun bringPanelToFront() {
        val p = panel ?: return
        val lp = panelLp ?: return
        try {
            wm.removeView(p)
            wm.addView(p, lp)
        } catch (_: Exception) {}
    }

    private fun setStatus(t: String) {
        statusView?.text = t
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ───────────── التسجيل ─────────────

    private fun startRecording() {
        if (recording || playing) return
        recorded.clear()
        firstDown = -1L

        val v = View(this).apply { setBackgroundColor(0x22FF0000) }
        v.setOnTouchListener { _, e -> onRecordTouch(e); true }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        recLayer = v
        recLp = lp
        recording = true
        bringPanelToFront()
        setStatus("تسجيل…")
    }

    private fun stopRecording() {
        recLayer?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        recLayer = null
        recLp = null
        if (recording) {
            recording = false
            Store.save(this, recorded.toList())
            setStatus("${recorded.size} خطوة")
        }
    }

    private fun onRecordTouch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                downT = e.eventTime
            }
            MotionEvent.ACTION_UP -> {
                if (firstDown < 0) firstDown = downT
                val step = Step(
                    offset = downT - firstDown,
                    duration = (e.eventTime - downT).coerceAtLeast(1),
                    x1 = downX, y1 = downY, x2 = e.rawX, y2 = e.rawY
                )
                recorded.add(step)
                setStatus("${recorded.size}")
                forward(step)
            }
        }
    }

    /** نمرّر الحركة للعبة تحت الطبقة الشفافة حتى تلعب بشكل طبيعي أثناء التسجيل. */
    private fun forward(step: Step) {
        val v = recLayer ?: return
        val lp = recLp ?: return
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(v, lp)

        val cb = object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) = restoreLayer()
            override fun onCancelled(g: GestureDescription?) = restoreLayer()
        }
        if (!dispatchGesture(buildGesture(step, 1f), cb, null)) restoreLayer()
    }

    private fun restoreLayer() {
        val v = recLayer ?: return
        val lp = recLp ?: return
        if (!recording) return
        lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    // ───────────── التشغيل ─────────────

    private fun startPlayback() {
        if (playing) return
        if (recording) stopRecording()
        val steps = Store.load(this)
        if (steps.isEmpty()) {
            toast("ما في خطوات محفوظة. سجّل أول.")
            return
        }
        playing = true
        setStatus("تشغيل…")
        playIteration(steps, 0, Store.speed(this), Store.repeat(this))
    }

    private fun playIteration(steps: List<Step>, iter: Int, speed: Float, repeat: Int) {
        if (!playing) return
        steps.forEach { s ->
            handler.postDelayed({
                if (playing) dispatchGesture(buildGesture(s, speed), null, null)
            }, (s.offset / speed).toLong())
        }
        val last = steps.last()
        val total = ((last.offset + last.duration) / speed).toLong() + 400L
        handler.postDelayed({
            if (!playing) return@postDelayed
            val next = iter + 1
            if (repeat == 0 || next < repeat) {
                setStatus("دورة ${next + 1}")
                playIteration(steps, next, speed, repeat)
            } else {
                stopPlayback()
            }
        }, total)
    }

    private fun stopPlayback() {
        playing = false
        handler.removeCallbacksAndMessages(null)
        setStatus("جاهز")
    }

    private fun stopAll() {
        if (recording) stopRecording()
        if (playing) stopPlayback()
    }

    // ───────────── بناء الحركة ─────────────

    private fun buildGesture(s: Step, speed: Float): GestureDescription {
        val moved = hypot(s.x2 - s.x1, s.y2 - s.y1) > 12f
        val path = Path().apply {
            moveTo(s.x1, s.y1)
            if (moved) lineTo(s.x2, s.y2)
        }
        var d = (s.duration / speed).toLong()
        if (!moved && d < 300) d = 50 // لمسة عادية
        d = d.coerceIn(1, 60_000)
        return GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, d))
            .build()
    }
}
